"""
This is testing of all individual functions in Churn ML Library. 

Author: Mehul Kumawat
Date: 04/30/2024
"""

import os
import logging
import pytest
from churn_library import (
    import_data,
    perform_eda,
    encoder_helper,
    perform_feature_engineering,
    train_models,
)
from constants import DATA_PATH, LOG_PATH, EDA_PATH, CAT_COLUMNS


# pylint: disable=C0103,W0621

# logging.basicConfig(
#     filename='./logs/churn_library.log',
#     level=logging.INFO,
#     filemode='w',
#     format='%(name)s - %(levelname)s - %(message)s')

churn_logger = logging.getLogger(__name__)
churn_logger.setLevel(logging.INFO)
f_handler = logging.FileHandler(LOG_PATH + "churn_library.log")
f_format = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
f_handler.setFormatter(f_format)
f_handler.setLevel(logging.INFO)
churn_logger.addHandler(f_handler)


@pytest.fixture(scope="module")
def path():
    """
    pytest fixture for path
    """
    return DATA_PATH


def test_import(path):
    """
    test data import - This will test the import_data func to read data and 
    ensure that df var is not empty.
    """
    try:
        df = import_data(path)
        pytest.df = df
        churn_logger.info("Testing import_data: SUCCESS")
        assert df is not None
    except FileNotFoundError as err:
        churn_logger.error("Testing import_data: The file wasn't found")
        raise err
    except AssertionError as err:
        churn_logger.error("dataframe is empty")
        raise err

    try:
        assert df.shape[0] > 0
        assert df.shape[1] > 0
    except AssertionError as err:
        churn_logger.error(
            "Testing import_data: The file doesn't appear to have rows and columns"
        )
        raise err

    try:
        assert df["Attrition_Flag"] is not None
        churn_logger.info("Testing import_data: Attrition_Flag is present")
    except AssertionError as err:
        churn_logger.error(
            "Testing import_data: Attrition_Flag is not present!")
        raise err


def test_eda():
    """
    test perform eda function -> This will test the file creation for plots of EDA with given dataframe.
    """
    df = pytest.df
    image_file_names = [
        "churn_distribution.png",
        "customer_age_distribution.png",
        "heatmap.png",
        "total_transaction_distribution.png",
        "marital_status_distribution.png",
    ]
    try:
        perform_eda(df)
        for file in image_file_names:
            assert os.path.exists(EDA_PATH + file) is True
        churn_logger.info("Testing test_eda: SUCCESS")
    except AssertionError as err:
        churn_logger.error("Testing test_eda: The plots don't exists")
        raise err


@pytest.fixture(scope="module", params=[CAT_COLUMNS])
def encoder_params(request):
    """
    Fixture - The test function test_encoder_helper will
    use the parameters returned by encoder_params() as arguments
    """
    cat_features = request.param
    # get dataset from pytest Namespace
    df = pytest.df.copy()
    return df, cat_features


def test_encoder_helper(encoder_params):
    """
    test encoder helper -> This will test that whether given cat columns are successfully encoded or not.
    """

    df, cat_features = encoder_params
    try:
        df = encoder_helper(df, cat_features)
        churn_logger.info("Testing encoder_helper: SUCCESS")

    except KeyError as err:
        churn_logger.error(
            "Testing encoder_helper with %s failed: Check for categorical features",
            cat_features,
        )
        raise err

    except Exception as err:
        churn_logger.error(
            "Testing encoder_helper failed - Error type %s",
            type(err))
        raise err

    try:
        for col in cat_features:
            assert df[col + "_Churn"] is not None
        churn_logger.info("All categorical columns were encoded")

    except AssertionError as err:
        churn_logger.error(
            "At least one categorical columns was NOT encoded"
        )
        raise err


def test_perform_feature_engineering():
    """
    test perform_feature_engineering -> This will create train and test data and ensure that they are not empty.
    """
    df = pytest.df.copy()
    try:
        X_train, X_test, y_train, y_test = perform_feature_engineering(df)
        churn_logger.info("Testing perform_feature_engineering: SUCCESS")
    except Exception as err:
        churn_logger.error("Testing perform_feature_engineering: Some Error")
        raise err

    try:
        assert X_train.shape[0] > 0
        assert X_train.shape[1] > 0
        assert X_test.shape[0] > 0
        assert X_test.shape[1] > 0
        assert y_train.shape[0] > 0
        assert y_test.shape[0] > 0
        churn_logger.info(
            "perform_feature_engineering returned Train / Test set of shape %s %s",
            X_train.shape,
            X_test.shape,
        )

    except AssertionError:
        churn_logger.error(
            "The returned train / test datasets do not appear to have rows and columns"
        )


def test_train_models():
    """
    test train_models ->This test will check if the models are trained and stored in given path.
    """
    df = pytest.df.copy()
    X_train, X_test, y_train, y_test = perform_feature_engineering(df)
    try:
        train_models(X_train, X_test, y_train, y_test)
        churn_logger.info("Testing train_models: SUCCESS")
        assert os.path.exists("./models/logistic_model.pkl") is True
        assert os.path.exists("./models/rfc_model.pkl") is True
       
    except Exception as err:
        churn_logger.error("Testing train_models: Some Error")
        raise err
    except AssertionError as err:
        churn_logger.error("Models are not created or stored in given path")
        raise err 


if __name__ == "__main__":
    pass
