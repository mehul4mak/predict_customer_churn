"""
Project for Telecom Customer Churn

Author: Mehul Kumawat
Date: 04/29/2024
"""


# import libraries
from typing import List, Any, Tuple
import os
import logging
# import shap
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
# from sklearn.preprocessing import normalize
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import plot_roc_curve, classification_report
from constants import (
    CAT_COLUMNS,
    KEEP_COLUMNS,
    DATA_PATH,
    MODEL_PATH,
    EDA_PATH,
    RESULT_PATH,
    PARAM_GRID,
)


sns.set_theme()

os.environ["QT_QPA_PLATFORM"] = "offscreen"

logger = logging.getLogger(__name__)
logger.setLevel(logging.NOTSET)
# f_handler = logging.FileHandler(LOG_PATH + 'app.log')
# ,datefmt='%d-%b-%y %H:%M:%S)
# f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# f_handler.setFormatter(f_format)
# f_handler.setLevel(logging.DEBUG)
# logger.addHandler(f_handler)


def import_data(pth: str) -> pd.DataFrame:
    """
    returns dataframe for the csv found at pth

    input:
            pth: a path to the csv
    output:
            df: pandas dataframe
    """
    #pylint: disable=C0103
    logger.debug("Importing Data...")
    df = pd.read_csv(pth, index_col=0)
    logger.debug("Successfully data imported")
    return df


def perform_eda(df: pd.DataFrame) -> None:
    """
    perform eda on df and save figures to images folder
    input:
            df: pandas dataframe

    output:
            None
    """
    #pylint: disable=C0103
    logger.debug("Running 'perform_eda' func")

    df["Churn"] = df["Attrition_Flag"].apply(
        lambda val: 0 if val == "Existing Customer" else 1
    )
    logger.debug("Created Churn Column")

    logger.debug("Created Churn Distribution Plot ")
    plt.figure(figsize=(20, 10))
    df["Churn"].hist()
    plt.savefig(EDA_PATH + "churn_distribution.png")
    logger.debug("Created and saved Churn Distribution Plot ")

    plt.figure(figsize=(20, 10))
    df["Customer_Age"].hist()
    plt.savefig(EDA_PATH + "customer_age_distribution.png")
    logger.debug("Created and saved Customer Age Distribution Plot ")

    plt.figure(figsize=(20, 10))
    df.Marital_Status.value_counts("normalize").plot(kind="bar")
    plt.savefig(EDA_PATH + "marital_status_distribution.png")
    logger.debug("Created and saved Marital Status Distribution Plot ")

    plt.figure(figsize=(20, 10))
    # distplot is deprecated. Use histplot instead
    # sns.distplot(df['Total_Trans_Ct']);
    # Show distributions of 'Total_Trans_Ct' and add a smooth curve obtained
    # using a kernel density estimate
    sns.histplot(df["Total_Trans_Ct"], stat="density", kde=True)
    plt.savefig(EDA_PATH + "total_transaction_distribution.png")
    logger.debug("Created and saved Total Txn Distribution Plot ")

    plt.figure(figsize=(20, 10))
    sns.heatmap(df.corr(), annot=False, cmap="Dark2_r", linewidths=2)
    # plt.show()
    plt.savefig(EDA_PATH + "heatmap.png")
    logger.debug("Created and saved Heatmap ")
    logger.debug("Successfully run : 'perform_eda' func")


def encoder_helper(
    df: pd.DataFrame, category_lst: List[str], response: str = "Churn"
) -> pd.DataFrame:
    """
    helper function to turn each categorical column into a new column with
    propotion of churn for each category - associated with cell 15 from the
    notebook

    input:
            df: pandas dataframe
            category_lst: list of columns that contain categorical features
            response: string of response name [optional argument that could
            be used for naming variables or index y column]

    output:
            df: pandas dataframe with new columns for
    """
    #pylint: disable=C0103
    logger.debug("Running 'encode_helper' func...")

    logger.debug("Added average value columns as features")
    for col_name in category_lst:
        val_list = []

        col_groups = df.groupby(col_name).mean()["Churn"]

        for val in df[col_name]:
            val_list.append(col_groups.loc[val])

        df[col_name + "_" + response] = val_list

    df.drop(category_lst, axis=1, inplace=True)
    logger.debug("Successfully run : 'encode_helper' func")
    return df


def perform_feature_engineering(
    df: pd.DataFrame, response: str = "Churn"
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Perform Feature engineering on raw data and return train test data for Ml training
    input:
              df: pandas dataframe
              response: string of response name [optional argument that could be used
              for naming variables or index y column]

    output:
              X_train: X training data
              X_test: X testing data
              y_train: y training data
              y_test: y testing data
    """
    #pylint: disable=C0103
    logger.debug("Running 'perform_feature_engineering' func")
    df = encoder_helper(df, CAT_COLUMNS, response)
    X = pd.DataFrame()
    y = df["Churn"]

    logger.debug("Keeping desired columns")
    X[KEEP_COLUMNS] = df[KEEP_COLUMNS]

    # This cell may take up to 15-20 minutes to run
    # train test split
    logger.debug("Train-Test Split")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )
    logger.debug("Successfully run : 'perform_feature_engineering' func ")
    return X_train, X_test, y_train, y_test


def classification_report_image(  # pylint: disable=R0913
    y_train,
    y_test,
    y_train_preds_lr,
    y_train_preds_rf,
    y_test_preds_lr,
    y_test_preds_rf,
):
    """
    produces classification report for training and testing results and stores report as image
    in images folder
    input:
            y_train: training response values
            y_test:  test response values
            y_train_preds_lr: training predictions from logistic regression
            y_train_preds_rf: training predictions from random forest
            y_test_preds_lr: test predictions from logistic regression
            y_test_preds_rf: test predictions from random forest

    output:
             None
    """
    logger.debug("Running 'classification_report_image' func...")
    plt.clf()
    plt.rc("figure", figsize=(5, 5))
    # plt.text(0.01, 0.05, str(model.summary()), {'fontsize': 12}) old approach
    plt.text(
        0.01,
        1.1,
        str("Random Forest Train"),
        {"fontsize": 10},
        fontproperties="monospace",
    )
    plt.text(
        0.01,
        0.01,
        str(classification_report(y_test, y_test_preds_rf)),
        {"fontsize": 10},
        fontproperties="monospace",
    )  # approach improved by OP -> monospace!
    plt.text(
        0.01,
        0.5,
        str("Random Forest Test"),
        {"fontsize": 10},
        fontproperties="monospace",
    )
    plt.text(
        0.01,
        0.6,
        str(classification_report(y_train, y_train_preds_rf)),
        {"fontsize": 10},
        fontproperties="monospace",
    )  # approach improved by OP -> monospace!
    plt.axis("off")
    plt.savefig(RESULT_PATH + "rf_results.png")

    plt.clf()
    plt.rc("figure", figsize=(5, 5))
    plt.text(
        0.01,
        1.1,
        str("Logistic Regression Train"),
        {"fontsize": 10},
        fontproperties="monospace",
    )
    plt.text(
        0.01,
        0.01,
        str(classification_report(y_train, y_train_preds_lr)),
        {"fontsize": 10},
        fontproperties="monospace",
    )  # approach improved by OP -> monospace!
    plt.text(
        0.01,
        0.5,
        str("Logistic Regression Test"),
        {"fontsize": 10},
        fontproperties="monospace",
    )
    plt.text(
        0.01,
        0.6,
        str(classification_report(y_test, y_test_preds_lr)),
        {"fontsize": 10},
        fontproperties="monospace",
    )  # approach improved by OP -> monospace!
    plt.axis("off")
    plt.savefig(RESULT_PATH + "logistic_results.png")
    logger.debug("Successfully run : 'classification_report_image' func")


def feature_importance_plot(
        model: Any,
        X_data: pd.DataFrame,
        output_pth: str) -> None:
    """
    creates and stores the feature importances in pth
    input:
            model: model object containing feature_importances_
            X_data: pandas dataframe of X values
            output_pth: path to store the figure

    output:
             None
    """
    #pylint: disable=C0103
    logger.debug("Running 'feature_importance_plot' func...")
    # Calculate feature importances
    importances = model.best_estimator_.feature_importances_
    # Sort feature importances in descending order
    indices = np.argsort(importances)[::-1]

    # Rearrange feature names so they match the sorted feature importances
    names = [X_data.columns[i] for i in indices]

    # Create plot
    plt.figure(figsize=(20, 5))

    # Create plot title
    plt.title("Feature Importance")
    plt.ylabel("Importance")

    # Add bars
    plt.bar(range(X_data.shape[1]), importances[indices])

    # Add feature names as x-axis labels
    plt.xticks(range(X_data.shape[1]), names, rotation=90)
    plt.savefig(output_pth)

    # explainer = shap.TreeExplainer(model.best_estimator_)
    # shap_values = explainer.shap_values(X_data)
    # shap.summary_plot(shap_values, X_data, plot_type="bar")
    # # plt.savefig("./images/results/feature_importances.png")
    # plt.savefig(output_pth)

    logger.debug("Successfully run : 'feature_importance_plot' func")


def train_models(
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.DataFrame,
    y_test: pd.DataFrame,
) -> None:
    """
    train, store model results: images + scores, and store models
    input:
              X_train: X training data
              X_test: X testing data
              y_train: y training data
              y_test: y testing data
    output:
              None
    """
    #pylint: disable=C0103
    logger.debug("Running 'train_models' func...")
    rfc = RandomForestClassifier(random_state=42)
    # Use a different solver if the default 'lbfgs' fails to converge
    # Reference:
    # https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
    lrc = LogisticRegression(solver="lbfgs", max_iter=3000)

    cv_rfc = GridSearchCV(estimator=rfc, param_grid=PARAM_GRID, cv=5)

    cv_rfc.fit(X_train, y_train)

    lrc.fit(X_train, y_train)
    logger.debug("Models trained")

    y_train_preds_rf = cv_rfc.best_estimator_.predict(X_train)
    y_test_preds_rf = cv_rfc.best_estimator_.predict(X_test)
    logger.debug("Prediction on train and test data")

    y_train_preds_lr = lrc.predict(X_train)
    y_test_preds_lr = lrc.predict(X_test)

    # scores
    logger.debug("Classification Reporting...")
    print("random forest results")
    print("test results")
    print(classification_report(y_test, y_test_preds_rf))
    print("train results")
    print(classification_report(y_train, y_train_preds_rf))

    print("logistic regression results")
    print("test results")
    print(classification_report(y_test, y_test_preds_lr))
    print("train results")
    print(classification_report(y_train, y_train_preds_lr))

    lrc_plot = plot_roc_curve(lrc, X_test, y_test)

    # plots
    plt.figure(figsize=(15, 8))
    ax = plt.gca()
    rfc_disp = plot_roc_curve(  # pylint: disable=W0612
        cv_rfc.best_estimator_, X_test, y_test, ax=ax, alpha=0.8
    )
    save_path = "./images/results/"

    lrc_plot.plot(ax=ax, alpha=0.8)
    plt.savefig(save_path + "roc_curve_result.png")
    # plt.show()

    # save best model
    logger.debug("Saving the models...")
    joblib.dump(cv_rfc.best_estimator_, MODEL_PATH + "rfc_model.pkl")
    joblib.dump(lrc, MODEL_PATH + "logistic_model.pkl")

    feature_importance_plot(
        cv_rfc,
        X_data=X_test,
        output_pth=RESULT_PATH +
        "feature_importances.png")
    classification_report_image(
        y_train,
        y_test,
        y_train_preds_lr,
        y_train_preds_rf,
        y_test_preds_lr,
        y_test_preds_rf,
    )

    logger.debug("Successfully run : 'train_models' func")


def main() -> None:
    """
    Main func of module which runs required function to read data, perform eda and feature engineering and training ML Models.
    """
    # pylint: disable=C0103
    logger.debug("Running main...")
    df: pd.DataFrame = import_data(DATA_PATH)
    perform_eda(df)
    X_train, X_test, y_train, y_test = perform_feature_engineering(df)
    train_models(X_train, X_test, y_train, y_test)
    logger.debug("Successfully run")


if __name__ == "__main__":
    main()
