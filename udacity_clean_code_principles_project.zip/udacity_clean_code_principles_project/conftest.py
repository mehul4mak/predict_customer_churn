'''
conftest.py for fixtures
'''
# pylint: disable=E1128
import pytest

def df_plugin():
    '''
    This is pytest fixture boilerplate code.
    '''
    return None

# Creating a Dataframe object 'pytest.df' in Namespace
def pytest_configure():
    '''
    pytest configure -> This is pytest fixture boilerplate code.
    '''
    pytest.df = df_plugin()
